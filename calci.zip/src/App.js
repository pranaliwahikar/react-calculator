 
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import { Button, Container, Table } from 'react-bootstrap';

function App() {
  return (
    <div className="App">
      <Container>
        <div className='calculator'>
        <div className='calcibtn'>
          <Table>
          <tbody>
          <tr>
            <td colSpan={4}>
            <div className="display">
          <h3>result = </h3>
        </div>
            </td>
          </tr>
            <tr>
              <td><Button className='btn-num'>1</Button></td>
              <td><Button className='btn-num'>2</Button></td>
              <td><Button className='btn-num'>3</Button></td>
              <td><Button className='btn-op'>+</Button></td>
            </tr>
             <tr>
              <td><Button className='btn-num'>4</Button></td>
              <td><Button className='btn-num'>5</Button></td>
              <td><Button className='btn-num'>6</Button></td>
              <td><Button className='btn-op'>-</Button></td>
            </tr>
             <tr>
              <td><Button className='btn-num'>7</Button></td>
              <td><Button className='btn-num'>8</Button></td>
              <td><Button className='btn-num'>9</Button></td>
              <td><Button className='btn-op'>x</Button></td>
            </tr>
             <tr>
              <td><Button className='btn-num'>/</Button></td>
              <td><Button className='btn-num'>0</Button></td>
              <td><Button className='btn-num'>.</Button></td>
              <td><Button className='btn-op'>=</Button></td>
            </tr>
            <tr>
              <td  colSpan={4}><Button >Reset</Button></td> 
            </tr>
            </tbody>
          </Table>
        </div>
        </div>
      </Container>
    </div>
  );
}

export default App;
